const car = (name = ["Micheal", "Melissa", "Melanie"], color = "yellow") =>{
    comnsole.log(`'My ${color} car has the following people in the back seat ${name}`)
}
car();